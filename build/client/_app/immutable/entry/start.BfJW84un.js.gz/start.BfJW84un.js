import{l as o,a as r}from"../chunks/CpgjVRCa.js";export{o as load_css,r as start};
