import{l as o,a as r}from"../chunks/DNNqZtjz.js";export{o as load_css,r as start};
