import{l as o,a as r}from"../chunks/CzIeTo2k.js";export{o as load_css,r as start};
